package com.Unific.SoftwareEngTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareEngTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
