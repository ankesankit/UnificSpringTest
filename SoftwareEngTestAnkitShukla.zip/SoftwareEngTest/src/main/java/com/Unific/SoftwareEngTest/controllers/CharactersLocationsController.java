package com.Unific.SoftwareEngTest.controllers;

import com.Unific.SoftwareEngTest.Models.Location;
import com.Unific.SoftwareEngTest.Models.Result;
import com.Unific.SoftwareEngTest.services.CharacterServices;
import com.Unific.SoftwareEngTest.services.LocationServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Log4j2
@RestController
public class CharactersLocationsController {

    @Autowired
    private CharacterServices characterServices;

    @Autowired
    private LocationServices locationServices;

    @Value("${app.outputFileType}")
    private String outputFileType;

    @Autowired
    private ObjectMapper mapper;

    @GetMapping(value = "/getLocations/")
    public Location.ResultLocation[] getLocations( @RequestParam String type )
        throws IOException {

        log.info( "Got the call to get all location of type {} ", type );

        final Location.ResultLocation[] locations = locationServices.getLocations( type );

        mapper.writeValue( new File( "LocationOutput" + outputFileType ), locations );

        log.info( " request processed :  All locations written to o/p file {} ",  "LocationOutput" + outputFileType );

        return locations;

    }

    @GetMapping(value = "/get2Characters/")
    public List<Result> getTwoCharacters( @RequestParam String gender, @RequestParam String status )
        throws IOException {

        log.info( "Got the call to get any two characters of gender {} and status {} ", gender , status );

        final Result[] characters = characterServices.getCharacters( gender, status );

        final List<Result> value = Arrays.asList( characters[0], characters[1] );

        mapper.writeValue( new File( "charOutput" + outputFileType ), value );

        log.info( " request processed : two characters written to o/p file {} ",  "charOutput" + outputFileType );

        return value;

    }

}
