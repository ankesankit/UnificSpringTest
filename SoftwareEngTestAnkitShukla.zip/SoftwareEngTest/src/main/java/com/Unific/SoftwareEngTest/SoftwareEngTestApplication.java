package com.Unific.SoftwareEngTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftwareEngTestApplication {


    public static void main( String[] args ) {
        SpringApplication.run( SoftwareEngTestApplication.class, args );
    }

}
